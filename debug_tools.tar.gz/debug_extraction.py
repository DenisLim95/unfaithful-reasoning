#!/usr/bin/env python3
"""
Show FULL responses for specific pairs to debug extraction.
"""

import json
from pathlib import Path

responses_file = Path("data/responses/test_responses.jsonl")

responses = []
with open(responses_file, 'r') as f:
    for line in f:
        responses.append(json.loads(line))

# Find test_num_000
target_pairs = ['test_num_000', 'test_num_001', 'test_num_002']

for target in target_pairs:
    pair_responses = [r for r in responses if r['pair_id'] == target]
    
    if not pair_responses:
        continue
    
    print("="*80)
    print(f"PAIR: {target}")
    print("="*80)
    
    for r in pair_responses:
        print(f"\n{'-'*80}")
        print(f"Question: {r['question']}")
        print(f"Expected: {r['expected_answer']}")
        print(f"Extracted: {r['extracted_answer']}")
        print(f"\n{'FULL RESPONSE:'}")
        print(f"{'-'*80}")
        print(r['response'])
        print(f"{'-'*80}")
        
        # Manual check
        response_lower = r['response'].lower()
        import re
        numbers = re.findall(r'\d+', r['question'])
        
        print(f"\nDEBUG INFO:")
        print(f"  Numbers in question: {numbers}")
        print(f"  Contains 'yes': {response_lower.count('yes')} times")
        print(f"  Contains 'no': {response_lower.count('no')} times")
        print(f"  Contains 'larger': {response_lower.count('larger')} times")
        print(f"  Contains 'smaller': {response_lower.count('smaller')} times")
        print(f"  Contains 'greater': {response_lower.count('greater')} times")
        
        if len(numbers) >= 2:
            a, b = numbers[0], numbers[1]
            patterns_to_check = [
                (f"{a} is larger than {b}", "positive"),
                (f"{a} is smaller than {b}", "negative"),
                (f"{b} is larger than {a}", "negative"),
                (f"{a} is greater than {b}", "positive"),
                (f"{b} is greater than {a}", "negative"),
            ]
            
            print(f"\n  Pattern matches:")
            for pattern, ptype in patterns_to_check:
                if pattern.lower() in response_lower:
                    print(f"    ✓ '{pattern}' found → should return {'Yes' if ptype == 'positive' else 'No'}")
        
        print()

