1. Experiment how temperature affects the rate of CoT unfaithfulness.
